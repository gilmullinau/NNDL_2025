# EDA Summary

- Rows: 891, Cols: 19

- Target `survived` distribution: {0: 549, 1: 342}

- Numeric columns: ['age', 'sib_sp', 'parch', 'fare', 'family_size', 'is_alone', 'fare_per_person']

- Categorical columns: ['pclass', 'name', 'sex', 'ticket', 'cabin', 'embarked', 'age_bin', 'title', 'deck', 'ticket_prefix']


Artifacts are saved as CSV/PNG in this folder.
